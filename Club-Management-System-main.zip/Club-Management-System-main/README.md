# Club-Management-System
Mini web project for dbms lab-vtu
The main objective behind the need of club management system is easy supervision of various clubs and societies.
Helps us to explore all activities and events happening in/around college.
The website not only maintains a database of all the details related to the events but also showcases the performance of each club in different aspects for better understanding of each club's growth.


# Expected Outcomes
1.One stop for all clubs information and seeing how active they are
2.Adding or removing members
3.Contact information of the core members
4.Information about recent activities happening around the college and to register for them
5.Searching any existing member in the system for details information by the last name and ID number.
6.Can verify the student request by accepting or rejecting their response.

There are three different login pages
1. Admin Login
2. Student Login
3. Co-ordinator Login








